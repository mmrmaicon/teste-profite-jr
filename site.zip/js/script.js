$( document ).ready(function() {

	//Carousel Banner
	var owlBanner = $('.owl-carousel-banner');
      owlBanner.owlCarousel({
        margin: 10,
        nav: true,
        center: true,
        loop: true,
        navText: false,
        items:1
      });

     //Carousel Produto
     $(".owl-carousel-produtos").owlCarousel({
    jsonPath : './json/produtos.json',
    jsonSuccess : customDataSuccess
  });

     $.ajax({
	url: './json/produtos.json',
	dataType: 'json',
	success: function(data) {
		var content = '';
		for (i in data.owl) {
            content += data.owl[i].item;
        }

		owl.trigger('insertContent.owl',content);
	}
});
 
    /* var owlProdutos = $('.owl-carousel-produtos');
      owlProdutos.owlCarousel({
        margin: 1,
        nav: true,
        center: true,
        loop: true,
        navText: false,
        jsonPath : "./json/produtos.json",
        jsonSuccess : customDataSuccess,
        items:4,
        responsiveClass: true,
                responsive: {
                  0: {
                    items: 1
                  },
                  500: {
                    items: 2
                  },
                  600: {
                    items: 3
                  },
                  1000: {
                    items: 5
                  }
                }
      })*/
});

function customDataSuccess(data){
    var content = "";
    for(var i in data["items"]){
       
       var img = data["items"][i].img;
       var alt = data["items"][i].alt;
 
       content += "<img src=\"" +img+ "\" alt=\"" +alt+ "\">"
    }
    $("#owl-demo").html(content);
  }