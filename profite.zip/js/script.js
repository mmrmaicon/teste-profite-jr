$( document ).ready(function() {

	//Carousel Banner
	var owlBanner = $('.owl-carousel-banner');
      owlBanner.owlCarousel({
        margin: 10,
        nav: true,
        center: true,
        loop: true,
        navText: false,
        items:1
      });

     //Carousel Produto
      $.ajax({
        url: './json/produtos.json',
        dataType: 'json',
        success: function(data) {
          var content = '';
          var alt = "rete";
          for (i in data.itens) {
                  //content += "<div class='item'><img src=\"" +data.itens[i].img+ "\" alt=\"" +alt+ "\"></div>";
                 content += " <div class='item' id='item"+i+"' onclick='openProduto("+i+")'>";
                 content += "<div class='card vdivide'>";
                 content += "<div class='card-image'>";
                 content += "<img class='img-responsive' src=\"" +data.itens[i].img+ "\">";
                 content += "<p class='card-title'>" +data.itens[i].titulo+ "</p>";
                 content += "</div>";
                                
                 content += "<div class='card-content'>";
                 content += "<img class='img-responsive' src='./img/produtos/estrelas.png'>";
                 content += "<p>" +data.itens[i].descricao+ "</p>";
                 content += "</div>";
                 content += "<div class='btn-comprar'><img src='./img/produtos/carrinho.png'> <p>COMPRAR</p></div>";
                                
                 content += "</div>";
                 content += "<div class='card-action'>";
                                  
                content += " <div class='btn-econimizar'>" +data.itens[i].economize+ "</div>";
                content += "</div>";
                content += "</div>";
              }
          //$(".owl-carousel-produtos").trigger('insertContent.owl',content);
         $('.owl-carousel-produtos').append(content);
           $('.owl-carousel-produtos').owlCarousel({
                margin: 1,
                nav: true,
                center: true,
                loop: true,
                navText: false,
                items:3,
                responsiveClass: true,
                        responsive: {
                          0: {
                            items: 1
                          },
                          500: {
                            items: 2
                          },
                          600: {
                            items: 3
                          },
                          1000: {
                            items: 4
                          }
                        }
              })
        }


      });      
   });


function openProduto(id){
  //open modal
  $('#img-produto-selecionado').empty();
  var img = "./img/produtos/calcado"+(id+1)+"_zoom.png";
  $('#img-produto-selecionado').attr("src",img);
  
  $('#modalProdutos').modal('show');

}